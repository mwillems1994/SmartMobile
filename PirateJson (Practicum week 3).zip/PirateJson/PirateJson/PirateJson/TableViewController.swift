//
//  TableViewController.swift
//
//
//  Created by Marco Willems on 14/09/15.
//
//

import UIKit

class TableViewController: UITableViewController {
    var pirates : [Pirate] = []
    
    func addPirates() {
        RestApiManager.sharedInstance.getJson { json in
            for (index: String, subJson: JSON) in json {
                //Convert the Json object to a Pirate object
                var pirate : Pirate = self.makePirate(subJson.object)
                
                //Add pirate to the pirates array
                self.pirates.insert(pirate, atIndex: 0)
                dispatch_async(dispatch_get_main_queue(),{
                    tableView?.reloadData()
                })
            }
        }
    }
    
    func makePirate(pirateJson : AnyObject) -> Pirate
    {
        //Convert the Json object to a Pirate object
        let user:JSON =  JSON(pirateJson)
        return Pirate(
            name: user["name"].string!,
            life: user["life"].string!,
            yearsActive: user["years_active"].string!,
            countryOfOrigin: user["country_of_origin"].string!,
            comments: user["comments"].string!
        )
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        addPirates()
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        //Determines how many cells should be created
        return self.pirates.count;
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        //Add cells to the tableView, this function is called for every cell
        var cell = tableView.dequeueReusableCellWithIdentifier("CELL") as? UITableViewCell
        
        if cell == nil {
            cell = UITableViewCell(style: UITableViewCellStyle.Value1, reuseIdentifier: "CELL")
        }
        
        let pirate: Pirate = self.pirates[indexPath.row]
        cell!.textLabel?.text = pirate.Name
        //Return the cell to its view
        return cell!
    }
    
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        //This calles the showDetails segue, in other words it shows the detaildViewController
        self.performSegueWithIdentifier("showDetails", sender: self)
        
    }
    
    //This function is called everytime a cell has beel clicked
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        //Selects the pirate which has been clicked on, bases on the index
        let pirate: Pirate = self.pirates[self.tableView.indexPathForSelectedRow()!.row]
        
        //Access the DetailsViewController, so you can pass on the selected pirate
        var controller = segue.destinationViewController as! DetailsViewController
        controller.selectedPirate = pirate
    }
}
