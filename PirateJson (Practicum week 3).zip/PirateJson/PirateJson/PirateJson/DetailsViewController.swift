//
//  DetailsViewController.swift
//  PirateJson
//
//  Created by Marco Willems on 15/09/15.
//  Copyright (c) 2015 Marco Willems. All rights reserved.
//

import UIKit

class DetailsViewController: UIViewController {
    var selectedPirate : Pirate?
    
    @IBOutlet weak var lblName: UILabel!
    
    @IBOutlet weak var lblLife: UILabel!
    
    @IBOutlet weak var lblActiveYears: UILabel!
    
    @IBOutlet weak var lblCountryOfBirth: UILabel!
    
    @IBOutlet weak var tvComments: UITextView!
    
    @IBAction func btnDone(sender: UIButton) {
        self.dismissViewControllerAnimated(true, completion: nil)
    }
    override func viewWillAppear(animated: Bool) {
        lblName.text = selectedPirate?.Name
        lblLife.text = selectedPirate?.Life
        lblActiveYears.text = selectedPirate?.YearsActive
        lblCountryOfBirth.text = selectedPirate?.CountryOfOrigin
        tvComments.text = selectedPirate?.Comments
    }
}
