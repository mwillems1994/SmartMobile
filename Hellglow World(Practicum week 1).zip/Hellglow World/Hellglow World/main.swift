//
//  main.swift
//  Hellglow World
//
//  Created by Marco Willems on 03/09/15.
//  Copyright (c) 2015 Marco Willems. All rights reserved.
//

import Foundation

var blueLightAct = GlowAct(name: "The BlueLightAct", rating: 8, startTime: "22.20")
var redLightAct = GlowAct(name: "The RedLightAct", rating: 9, startTime: "23.20")
var eindhoven = City(name: "Eindhoven", population: 1000000, glowActs: [blueLightAct, redLightAct])
println(eindhoven.ShowInfo())

