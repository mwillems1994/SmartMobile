//
//  City.swift
//  Hellglow World
//
//  Created by Marco Willems on 03/09/15.
//  Copyright (c) 2015 Marco Willems. All rights reserved.
//

class City {
    var name: String!
    var population: Int32!
    var glowActs: [GlowAct]!
    
    init (name: String, population: Int32, glowActs: [GlowAct]) {
        self.name = name
        self.population = population
        self.glowActs = glowActs
    }
    
    func ShowInfo() -> String {
        var allStrings: String!
        allStrings = ""
        for act: GlowAct in glowActs{
            allStrings = allStrings + "\(act.ShowInfo()) \n"
        }
        
        return "In the city of \(self.name) there are currently living \(self.population) people \n There are currently \(glowActs.count) Glow acts. \n \n\(allStrings)"
    }
}
